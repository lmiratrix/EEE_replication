library(testthat)
library(blkvar)

test_check("blkvar")

